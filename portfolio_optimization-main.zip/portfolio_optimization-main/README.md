# Portfolio Optimization
Fine-Tuning Portfolios with Modern Portfolio Theory

Contributors:
- Jai Verma 
- Pulak Gautam 
